import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/sign.css';
import { Input, Form } from 'antd';
import { connect } from 'dva';
import { EyeInvisibleOutlined, EyeTwoTone } from '@ant-design/icons';
import 'antd/dist/antd.css';

const emailRegex = RegExp(
  /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
);

const passwordRegex = RegExp(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,}$/);

const formValid = ({ formErrors, ...rest }) => {
  let valid = true;
  // validate form errors being empty
  Object.values(formErrors).forEach(val => {
    val.length > 0 && (valid = false);
  });
  // validate the form was filled out
  Object.values(rest).forEach(val => {
    val === null && (valid = false);
  });
  return valid;
};

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {

      email: null,
      password: null,
      confirmpassword: null,
      notMatch: false,
      formErrors: {

        email: "",
        password: "",
        confirmpassword: "",
        pathMode: false,

      }
    };
  }
  componentWillReceiveProps(nextProps) {
    let { history } = this.props
    console.log("props",nextProps);
    if( (nextProps.data.email === this.state.email) && (nextProps.data.password === this.state.password)) {
      history.push('/dashboard');
    }
  }
  handleSubmit = e => {
    const { dispatch } = this.props;
    e.preventDefault();
    const values = {
      email: this.state.email,
      password: this.state.password, pathMode: true
    }
    console.log(values,"values");

    this.setState({
      notMatch: false,
    })
    var obj = {
      email_id: values.email,
      password: values.password
    }
    
    console.log("payload",obj);
    dispatch({
      type: 'user/actionSignIn',
      payload: obj,
    });
    
  };

  handleChange = e => {
    e.preventDefault();
    const { name, value } = e.target;
    let formErrors = { ...this.state.formErrors };
    switch (name) {

      case "email":
        formErrors.email = emailRegex.test(value)
          ? ""
          : "  enter email address";
        break;
      case "password":
        formErrors.password =
          passwordRegex.test(value) ? "" : "one special char, 1 number required";
        break;
      case "confirmpassword":
        formErrors.confirmpassword =
          value.length < 8 ? "Passwords do not match" : "";
        break
      default:
        break;
    }
    this.setState({ formErrors, [name]: value }, () => console.log(this.state));
  };

  render() {
    const { formErrors } = this.state;
    return (
      <div className="container-fluid" >
        <div className="row d-flex justify-content-center background">
          <div className=" col-12 mt-5 d-flex justify-content-center mb-5 pt-4 pb-5" >
            <div className="col-xl-3 col-lg-2 col-md-2 col-sm-1 d-sm-block d-none "></div>
            <div className="col-xl-6 col-lg-7 col-md-8 col-sm-9 col-xs-7   ">

              <div className="row mt-0 d-flex justify-content-center">
                <div className="col-12 mt-1  d-flex justify-content-center">
                </div>

                <div className="col-12 mt-4 d-flex justify-content-center">
                  <div className="col-xl-8 col-lg-9 col-md-10 col-sm-10 col-xs-8 mr-4 ml-4 mt-5">
                    <div className="  col-12" >
                      <div className="row ml-5 mb-5">
                        <h1>Appiness_Task</h1>
                      </div>
                      <div className="row">
                        <div className="  col-4 lableFont">
                          <label htmlFor="email">Email</label>
                        </div>
                        <div className="  col-8 d-flex justify-content-end">
                          {formErrors.email.length > 0 && (<span className="errorMessage">{formErrors.email}</span>)}

                        </div>
                      </div>
                      <Input
                        type="email"
                        name="email"
                        className="inputBox"
                        noValidate
                        onChange={this.handleChange}
                      />
                    </div>
                    <div className=" col-12 pt-4" >

                      <div className="row">
                        <div className="  col-4 lableFont">
                          <label htmlFor="Password">Password</label>
                        </div>
                        <div className="  col-8 d-flex justify-content-end">
                          {formErrors.password.length > 0 && (<span className="errorMessage">{formErrors.password}</span>)}

                        </div>
                      </div>
                      <Input.Password

                        name="password"
                        noValidate
                        onChange={this.handleChange}
                        className="inputBox"
                        iconRender={visible => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
                      />

                    </div>

                  </div>
                </div>
                <div className="col-12 mt-4 pt-4 d-flex justify-content-center mb-5">
                  <button type="submit" className="signinBtn" onClick={this.handleSubmit}>Sign In</button>
                </div>

              </div>

            </div>
            <div className="col-xl-3 col-lg-2 col-md-2 col-sm-1 d-sm-block d-none"></div>
          </div>
        </div>
      </div>
    );
  }
}


const mapStateToProps = (state) => {
  console.log(state);
  return {

    data: state.user.reducerSave[0],
    loading: state.loading.models.user,
    // AdminData: state.form.reducerbyId,

  }
}

export default connect(mapStateToProps)(Login)
