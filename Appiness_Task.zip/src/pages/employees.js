import React from "react";
import { connect } from 'dva';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Card, Row, Col } from "antd";

class Employees extends React.Component {
  componentDidMount() {
    const { dispatch } = this.props;
    var obj = {};
    dispatch({
      type: 'employee/actionList',
      payload: obj,
    });
  }
  

  render() {
    const { data } = this.props;
    const { Meta } = Card;
    return (
      <Row justify="center">
        {data.map((each)=>(
          <Card 
            hoverable
            style={{ width: 240 }}>
              <Meta title={each.name} description={each.email} />
          </Card>
        ))}
      </Row>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    data: state.employee.reducerList,
    loading: state.loading.models.user,
  }
}

export default connect(mapStateToProps)(Employees);
