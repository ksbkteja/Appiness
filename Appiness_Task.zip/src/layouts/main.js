import React, { Component } from 'react';
import 'antd/dist/antd.css';
import { Layout, Button} from 'antd';
import { Route, Link, withRouter} from 'react-router-dom';
import Employees from '../pages/employees';


class Main extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        };
    }
    render() {
        return (
            <Layout style={{ minHeight: "100vh",justifyContent:"center" }} className="background">
                <Link to="/"><Button style={{float:"right",margin:'10px'}}>Logout</Button></Link>
                <Employees/>
            </Layout>
        )
    }
}

export default withRouter(Main);