/*Added routing information  */

import React, { Fragment } from 'react';
import { ConnectedRouter } from 'react-router-redux';
import { Switch, Route } from 'react-router-dom';
import SignInForm from './pages/signinform';
import LayoutMain from './layouts/main';



function RouterConfig({history}) {
  return (
    <Fragment>
      <ConnectedRouter history={history}>
        <Switch>
          <Route path="/" exact component={SignInForm} />
          <Route path="/dashboard" component={LayoutMain} />
        </Switch>
      </ConnectedRouter>
    </Fragment>
  );
}

export default RouterConfig;

