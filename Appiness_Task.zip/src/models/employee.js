/* modal for Employee UI  */

// import { serviceSave, serviceList, serviceUpdate, serviceDelete } from '../services/employee';

export default {
  namespace: 'employee',

  state: {
    reducerSave: [],
    reducerList: [],
    reducerUpdate: [],
    reducerDelete: []
  },

  effects: {


    *actionList({ payload }, { call, put }) {
      // const respo = yield call(serviceList, payload);
      yield put({
        type: 'reducerList',
        payload: [{
          id: 1,
          name: "Jhon",
          age: "11",
          gender: "male",
          email: "jhon@gmail.com",
          phoneNo: "9415346313"
        },
        {
          id: 2,
          name: "Doe",
          age: "12",
          gender: "male",
          email: "doe@gmail.com",
          phoneNo: "9415346314"
        },
        {
          id: 3,
          name: "Sultan",
          age: "13",
          gender: "male",
          email: "sultan@gmail.com",
          phoneNo: "9415346315"
        },
        {
          id: 4,
          name: "Kumar",
          age: "14",
          gender: "male",
          email: "kumar@gmail.com",
          phoneNo: "9415346316"
        },
        {
          id: 5,
          name: "Rushi",
          age: "15",
          gender: "male",
          email: "rushi@gmail.com",
          phoneNo: "9415346317"
        },
        {
          id: 6,
          name: "Amit singh",
          age: "16",
          gender: "male",
          email: "amit@gmail.com",
          phoneNo: "9415346318"
        }],
      });

    },
  },

  reducers: {
    
    reducerList(state, action) {
      return {
        ...state,
        reducerList: action.payload,
      };
    },
  },
};
