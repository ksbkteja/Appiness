export default {
  namespace: 'user',

  state: {
    reducerSave: [],
  },

  effects: {
    
    *actionSignIn({ payload }, { call, put }) {
      // const response = yield call(serviceSignIn, payload);
      yield put({
        type: 'reducerSave',
        payload: [
          {
            email: "hruday@gmail.com",
            password: "hruday123"
          }
        ],
      });
    },

  },

  reducers: {
    reducerSave(state, action) {
      return {
        ...state,
        reducerSave: action.payload,
      };
    }

  },
};
